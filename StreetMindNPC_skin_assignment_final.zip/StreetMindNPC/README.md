# StreetMind NPC (NeoForge 1.21.1)

Prototype of a social NPC mod. This archive includes the project source and a GitHub Actions workflow that runs the build with Java 21.

## Compile using GitHub Actions (phone-friendly)
1. Create a GitHub repository and upload/extract the contents of this project to its root (the `.github/workflows/build.yml` file must be included).
2. Open the repository's **Actions** tab.
3. Select **Build StreetMind NPC** and press **Run workflow** (or push to `main`).
4. If the build succeeds, open the run and download the **StreetMindNPC-build** artifact.

## Local build
Use Java 21 and Gradle 8.8 or a compatible Gradle version:
`gradle build`

This is an unverified prototype; the CI workflow is intended to expose compiler errors, not guarantee the current source compiles. Rendering, complete AI, animations and third-party API bridges remain unfinished.
