package com.crystal.streetmind.social;

import java.util.UUID;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

/** Per-NPC persisted relationship ledger keyed by player UUID. Values are bounded to avoid runaway state. */
public final class RelationshipMemory {
    public static final int MAX_ENTRIES = 64;
    public static final int MAX_EVENT_NOTES = 12;
    private final Map<UUID, Record> records = new HashMap<>();

    public Record getOrCreate(UUID player) { return records.computeIfAbsent(player, k -> new Record()); }
    public void adjustReputation(UUID player, int amount) { Record r=getOrCreate(player); r.reputation=clamp(r.reputation+amount,-100,100); }
    public void adjustFamiliarity(UUID player, int amount) { Record r=getOrCreate(player); r.familiarity=clamp(r.familiarity+amount,0,100); }
    public void adjustTrust(UUID player, int amount) { Record r=getOrCreate(player); r.trust=clamp(r.trust+amount,-100,100); }
    public void addNote(UUID player, String note) {
        Record r=getOrCreate(player); if(note==null) return;
        String clean=note.substring(0,Math.min(note.length(),120));
        if(r.notes.size()==MAX_EVENT_NOTES) r.notes.remove(0);
        r.notes.add(clean);
    }
    public Record record(UUID player) { return records.get(player); }
    private static int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    public CompoundTag save() {
        CompoundTag root=new CompoundTag(); ListTag list=new ListTag();
        records.forEach((uuid,r)->{
            CompoundTag t=new CompoundTag(); t.putUUID("player",uuid);
            t.putInt("reputation",r.reputation); t.putInt("familiarity",r.familiarity); t.putInt("trust",r.trust);
            ListTag notes=new ListTag(); for(String n:r.notes){CompoundTag nt=new CompoundTag();nt.putString("note",n);notes.add(nt);}
            t.put("notes",notes); list.add(t);
        });
        root.put("records",list); return root;
    }
    public void load(CompoundTag root) {
        records.clear(); ListTag list=root.getList("records", Tag.TAG_COMPOUND);
        for(int i=0;i<Math.min(list.size(),MAX_ENTRIES);i++){
            CompoundTag t=list.getCompound(i); if(!t.hasUUID("player")) continue;
            Record r=new Record(); r.reputation=clamp(t.getInt("reputation"),-100,100);
            r.familiarity=clamp(t.getInt("familiarity"),0,100); r.trust=clamp(t.getInt("trust"),-100,100);
            ListTag notes=t.getList("notes",Tag.TAG_COMPOUND);
            for(int j=0;j<Math.min(notes.size(),MAX_EVENT_NOTES);j++) r.notes.add(notes.getCompound(j).getString("note"));
            records.put(t.getUUID("player"),r);
        }
    }
    public static final class Record {
        private int reputation, familiarity, trust;
        private final java.util.List<String> notes=new java.util.ArrayList<>();
        public int reputation(){return reputation;} public int familiarity(){return familiarity;} public int trust(){return trust;}
        public java.util.List<String> notes(){return java.util.List.copyOf(notes);}
    }
}
