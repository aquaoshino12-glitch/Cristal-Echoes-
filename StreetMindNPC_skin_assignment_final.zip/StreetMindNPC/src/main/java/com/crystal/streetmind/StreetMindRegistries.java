package com.crystal.streetmind;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

/** Central registration point, kept separate from gameplay logic. */
public final class StreetMindRegistries {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
        DeferredRegister.create(Registries.ENTITY_TYPE, StreetMindMod.MOD_ID);
    public static final DeferredHolder<EntityType<?>, EntityType<StreetMindEntity>> NPC =
        ENTITY_TYPES.register("npc", () -> EntityType.Builder.of(StreetMindEntity::new, MobCategory.CREATURE)
            .sized(0.6F,1.8F).build("npc"));
    private StreetMindRegistries(){}
    public static AttributeSupplier.Builder attributes(){
        return StreetMindEntity.createMobAttributes()
            .add(Attributes.MAX_HEALTH,20.0)
            .add(Attributes.MOVEMENT_SPEED,0.25)
            .add(Attributes.FOLLOW_RANGE,24.0)
            .add(Attributes.ATTACK_DAMAGE,2.0);
    }
}
