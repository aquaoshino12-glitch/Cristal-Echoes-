package com.crystal.streetmind;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.minecraft.world.entity.player.Player;

@Mod(StreetMindMod.MOD_ID)
public final class StreetMindMod {
 public static final String MOD_ID="streetmind";
 public StreetMindMod(net.neoforged.bus.api.IEventBus modBus){StreetMindRegistries.ENTITY_TYPES.register(modBus);modBus.addListener(this::registerAttributes);NeoForge.EVENT_BUS.addListener(this::onLivingDamage);}
 public StreetMindMod(){this(net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus());}
 private void registerAttributes(net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent event){event.put(StreetMindRegistries.NPC.get(),StreetMindRegistries.attributes().build());}
 private void onLivingDamage(LivingDamageEvent.Post event){if(event.getEntity() instanceof StreetMindEntity npc&&event.getSource().getEntity() instanceof Player player)npc.reactToPlayerAttack(player,event.getNewDamage());}
}
