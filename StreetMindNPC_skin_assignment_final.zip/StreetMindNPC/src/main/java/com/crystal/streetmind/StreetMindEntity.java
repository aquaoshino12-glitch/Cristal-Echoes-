package com.crystal.streetmind;

import com.crystal.streetmind.social.EmotionState;
import com.crystal.streetmind.social.RelationshipMemory;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Core social NPC. Weapon awareness is deliberately heuristic until a TaCZ API bridge is tested. */
public class StreetMindEntity extends PathfinderMob {
 private NPCProfile profile=NPCProfile.MALE_CIVIL_1;
 private final EmotionState emotions=new EmotionState();
 private final RelationshipMemory relationships=new RelationshipMemory();
 private int behaviorClock;
 private Player focusPlayer;
 public StreetMindEntity(EntityType<? extends StreetMindEntity> type,Level level){super(type,level);}
 @Override protected void registerGoals(){goalSelector.addGoal(8,new WaterAvoidingRandomStrollGoal(this,0.8));goalSelector.addGoal(9,new LookAtPlayerGoal(this,Player.class,10));goalSelector.addGoal(10,new RandomLookAroundGoal(this));}
 public NPCProfile profile(){return profile;} public void profile(NPCProfile p){profile=p==null?NPCProfile.MALE_CIVIL_1:p;} public EmotionState emotions(){return emotions;} public RelationshipMemory relationships(){return relationships;}
 @Override public void tick(){super.tick();if(level().isClientSide)return;emotions.tickCalm();if(++behaviorClock%10!=0)return;
  Player nearest=level().getNearestPlayer(this,12.0); if(nearest==null||nearest.isCreative()||nearest.isSpectator()){focusPlayer=null;return;} focusPlayer=nearest;
  boolean armed=isPlayerArmed(nearest); double distance=distanceTo(nearest);
  if(armed&&distance<9){emotions.addFear(profile.courage()<0.55?0.10:0.035);emotions.addStress(0.07);if(profile.aggression()>0.72)emotions.addAnger(0.04);}
  else if(distance<4){emotions.addCuriosity(0.01);}
  // Panic response: NPCs try to get away from a visible armed player or severe fear.
  if((armed&&emotions.fear()>0.35)||emotions.fear()>0.72){Vec3 away=position().subtract(nearest.position()).normalize();double speed=1.1+emotions.fear();getNavigation().moveTo(getX()+away.x*8,getY(),getZ()+away.z*8,speed);}
  // Aggressive profiles may retaliate after fear turns into anger; civilians do not become combatants by default.
  if(profile.aggression()>0.70&&emotions.anger()>0.65&&distance<3.2&&!armed){if(getAttackTargetCompat(nearest)){doHurtTarget(nearest);emotions.addStress(0.08);}}
 }
 private boolean getAttackTargetCompat(Player p){return !p.isCreative()&&!p.isSpectator()&&p.isAlive();}
 private boolean isPlayerArmed(Player p){Item a=p.getMainHandItem().getItem(),b=p.getOffhandItem().getItem();return isWeapon(a)||isWeapon(b);}
 private boolean isWeapon(Item item){if(item==Items.AIR)return false;if(item instanceof net.minecraft.world.item.SwordItem||item instanceof net.minecraft.world.item.AxeItem||item instanceof net.minecraft.world.item.BowItem||item instanceof net.minecraft.world.item.CrossbowItem||item instanceof net.minecraft.world.item.TridentItem)return true;String id=net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase();return id.contains("tacz")||id.contains("gun")||id.contains("rifle")||id.contains("pistol")||id.contains("shotgun");}
 @Override public InteractionResult mobInteract(Player player,InteractionHand hand){if(level().isClientSide)return InteractionResult.SUCCESS;var held=player.getItemInHand(hand);if(held.isEmpty()){var r=relationships.getOrCreate(player.getUUID());relationships.adjustFamiliarity(player.getUUID(),1);relationships.adjustTrust(player.getUUID(),1);emotions.addCuriosity(0.03);emotions.addAffection(profile.sociability()*0.025);emotions.addStress(-0.05);return InteractionResult.SUCCESS;}return super.mobInteract(player,hand);}
 /** Called by damage-event bridge when a player hurts this NPC. */
 public void reactToPlayerAttack(Player player,float damage){emotions.addFear(0.22+damage*0.025);emotions.addAnger(0.28);emotions.addStress(0.25);emotions.addViolence(0.18);relationships.adjustTrust(player.getUUID(),-8);relationships.adjustReputation(player.getUUID(),-12);relationships.addNote(player.getUUID(),"Attacked / witnessed violence");}
 /** Called by a future event bridge for calming/positive interactions. */
 public void rewardInteraction(Player player,int trust,int affection){relationships.adjustTrust(player.getUUID(),trust);relationships.adjustReputation(player.getUUID(),trust);relationships.adjustFamiliarity(player.getUUID(),2);emotions.addAffection(affection/100.0);emotions.addStress(-0.1);}
 @Override protected void addAdditionalSaveData(CompoundTag tag){super.addAdditionalSaveData(tag);tag.putInt("StreetMindProfile",profile.ordinal());tag.put("StreetMindRelations",relationships.save());tag.put("StreetMindEmotions",emotions.save());}
 @Override protected void readAdditionalSaveData(CompoundTag tag){super.readAdditionalSaveData(tag);if(tag.contains("StreetMindProfile"))profile=NPCProfile.fromId(tag.getInt("StreetMindProfile"));if(tag.contains("StreetMindRelations"))relationships.load(tag.getCompound("StreetMindRelations"));if(tag.contains("StreetMindEmotions"))emotions.load(tag.getCompound("StreetMindEmotions"));}
}
