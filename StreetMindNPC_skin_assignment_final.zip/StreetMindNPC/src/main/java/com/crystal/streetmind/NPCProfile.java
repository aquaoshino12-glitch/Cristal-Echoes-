package com.crystal.streetmind;

/** Stable profile IDs; texture and behavioral defaults are data, not scattered conditionals. */
public enum NPCProfile {
    DEALER("dealer_01", BodyType.MALE, 0.45, 0.55, 0.35, 0.65),
    // The former bandit skins are civilians per the corrected skin assignment.
    MALE_CIVIL_1("bandit_01", BodyType.MALE, 0.30, 0.70, 0.60, 0.75),
    MALE_CIVIL_2("bandit_02", BodyType.MALE, 0.35, 0.65, 0.55, 0.70),
    FEMALE_CIVIL_1("extra_skin_03", BodyType.FEMALE_SLIM, 0.30, 0.70, 0.60, 0.75),
    FEMALE_CIVIL_2("extra_skin_04", BodyType.FEMALE_SLIM, 0.35, 0.65, 0.55, 0.70),
    POLICE_FEMALE_1("extra_skin_01", BodyType.FEMALE_SLIM, 0.65, 0.45, 0.75, 0.55),
    POLICE_MALE_1("extra_skin_02", BodyType.MALE, 0.65, 0.45, 0.75, 0.55),
    POLICE_FEMALE_2("extra_skin_05", BodyType.FEMALE_SLIM, 0.65, 0.45, 0.75, 0.55),
    POLICE_MALE_2("extra_skin_06", BodyType.MALE, 0.65, 0.45, 0.75, 0.55),
    NIGHTCLUB_1("nightclub_female_01", BodyType.FEMALE_SLIM, 0.25, 0.70, 0.55, 0.75),
    NIGHTCLUB_2("nightclub_female_02", BodyType.FEMALE_SLIM, 0.30, 0.65, 0.60, 0.70),
    NIGHTCLUB_3("nightclub_female_03", BodyType.FEMALE_SLIM, 0.35, 0.60, 0.65, 0.70);

    public enum BodyType { MALE, FEMALE_SLIM }
    private final String texture;
    private final BodyType body;
    private final double aggression, sociability, courage, patience;
    NPCProfile(String texture, BodyType body, double aggression, double sociability, double courage, double patience) {
        this.texture=texture; this.body=body; this.aggression=aggression;
        this.sociability=sociability; this.courage=courage; this.patience=patience;
    }
    public String texturePath() { return "textures/entity/npc/" + texture + ".png"; }
    public BodyType bodyType() { return body; }
    public double aggression() { return aggression; }
    public double sociability() { return sociability; }
    public double courage() { return courage; }
    public double patience() { return patience; }
    public static NPCProfile fromId(int id) {
        NPCProfile[] values=values(); return values[Math.floorMod(id, values.length)];
    }
}
