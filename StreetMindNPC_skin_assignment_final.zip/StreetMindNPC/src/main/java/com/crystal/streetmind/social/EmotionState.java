package com.crystal.streetmind.social;
/** NPC emotion meters, normalized to 0..1 and slowly recovering over time. */
public final class EmotionState {
 private double fear, anger, stress, curiosity, affection, violence;
 public double fear(){return fear;} public double anger(){return anger;} public double stress(){return stress;} public double curiosity(){return curiosity;} public double affection(){return affection;} public double violence(){return violence;}
 public void fear(double v){fear=clamp(v);} public void anger(double v){anger=clamp(v);} public void stress(double v){stress=clamp(v);} public void curiosity(double v){curiosity=clamp(v);} public void affection(double v){affection=clamp(v);} public void violence(double v){violence=clamp(v);}
 public void addFear(double v){fear=clamp(fear+v);} public void addAnger(double v){anger=clamp(anger+v);} public void addStress(double v){stress=clamp(stress+v);} public void addCuriosity(double v){curiosity=clamp(curiosity+v);} public void addAffection(double v){affection=clamp(affection+v);} public void addViolence(double v){violence=clamp(violence+v);}
 public void tickCalm(){fear=Math.max(0,fear-0.0018); anger=Math.max(0,anger-0.001); stress=Math.max(0,stress-0.0012); curiosity=Math.max(0,curiosity-0.0005); violence=Math.max(0,violence-0.0003);}
 public net.minecraft.nbt.CompoundTag save(){var t=new net.minecraft.nbt.CompoundTag();t.putDouble("fear",fear);t.putDouble("anger",anger);t.putDouble("stress",stress);t.putDouble("curiosity",curiosity);t.putDouble("affection",affection);t.putDouble("violence",violence);return t;}
 public void load(net.minecraft.nbt.CompoundTag t){fear(t.getDouble("fear"));anger(t.getDouble("anger"));stress(t.getDouble("stress"));curiosity(t.getDouble("curiosity"));affection(t.getDouble("affection"));violence(t.getDouble("violence"));}
 private double clamp(double v){return Math.max(0,Math.min(1,v));}
}
